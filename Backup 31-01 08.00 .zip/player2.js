class Player2
{
    constructor()
    {
        this.x = 100
        this.y = 0
        this.lato = 40
        this.xc = this.lato + this.x
        this.yc = this.lato + this.y
    }
    show()
    {
        square(this.x, this.y, this.lato)
    }
    move()
    {   
        if(movimento == 1)
        {
            this.y = this.y - 5
            this.yc = this.yc - 5
        }
        if(movimento == 2)
        {
            this.x = this.x - 5
            this.xc = this.xc - 5
        }
        if(movimento == 3)
        {
            this.y = this.y + 5
            this.yc = this.yc + 5
        }
        if(movimento == 4)
        {
            this.x = this.x + 5
            this.xc = this.xc + 5
        }
    }
    hitsVertical(blocco) 
    {
        if (this.x < blocco.x + 50 && this.x + this.lato > blocco.x && this.y < blocco.y + 50 && this.y + this.lato > blocco.y) 
        {
            if(movimento == 1) 
            {  
                this.y += 5
            }
            if(movimento == 3) 
            { 
                this.y -= 5
            }
        }
    }
    
    hitsOrizontal(blocco) 
    {
        if (this.x < blocco.x + 50 && this.x + this.lato > blocco.x && this.y < blocco.y + 50 && this.y + this.lato > blocco.y) 
        {
            if (movimento == 2) 
            { 
                this.x += 5
            }
            if (movimento == 4) 
            { 
                this.x -= 5
            }
        }
    }
    
}