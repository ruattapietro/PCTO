class Player
{
    constructor()
    {
        this.x
        this.y
        this.katana = lama
    }
    show()
    {
        image(this.katana, xc - this.katana.width / 2, yc  - this.katana.height / 2)
    }
    hits(oggetto)
    {
        return collideCircleCircle(xc, yc, this.katana.height, oggetto.xc, oggetto.yc, oggetto.immagine.height)
    }

}