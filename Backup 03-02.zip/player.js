class Player 
{
    constructor() 
    {
        this.immagine = navicella;
        this.x = mouseX - this.immagine.width / 2;
        this.y = mouseY - this.immagine.height / 2;
        this.xc = mouseX;
        this.yc = mouseY;
        this.visible = true;
        this.blinking = false
        this.health = 100
    }

    show() 
    {
        if (this.visible == true) 
        {
            image(this.immagine, this.x, this.y);
            player.drawHealthBar()
        }
    }

    hits(oggetto) 
    {
        switch(oggetto.immagine)
        {
            case asteroide1:
                return collideCircleCircle(mouseX, mouseY, this.immagine.height - 50, oggetto.xc, oggetto.yc, oggetto.immagine.height - 40);
            case asteroide2:
                return collideCircleCircle(mouseX, mouseY, this.immagine.height - 50, oggetto.xc, oggetto.yc, oggetto.immagine.height - 25);
            case stella1:
                return collideCircleCircle(mouseX, mouseY, this.immagine.height - 50, oggetto.xc, oggetto.yc, oggetto.immagine.height - 20);
            case stella2:
                return collideCircleCircle(mouseX, mouseY, this.immagine.height - 50, oggetto.xc, oggetto.yc, oggetto.immagine.height - 20);
        }
        return collideCircleCircle(mouseX, mouseY, this.immagine.height - 50, oggetto.xc, oggetto.yc, oggetto.immagine.height - 50);
    }

    update() 
    {    
        this.x = mouseX - this.immagine.width / 2;
        this.y = mouseY - this.immagine.height / 2;
        this.xc = mouseX;
        this.yc = mouseY;
    }
    drawHealthBar() 
    {
        let barWidth = 100;
        let barHeight = 10;
        let healthPercentage = this.health / 100; // Normalizza la vita tra 0 e 1
        let greenWidth = barWidth * healthPercentage;

        // Posizione della barra sopra il player

        // Disegna la barra nera (sfondo)
        fill(255, 0, 0);
        rect(10, 10, barWidth, barHeight);

        // Disegna la barra verde (vita attuale)
        fill(0, 255, 0);
        rect(10, 10, greenWidth, barHeight);
    }
    blink() 
    {
        if (this.blinking) 
            return; // Evita di attivare più volte il blink
    
        this.blinking = true; // Imposta lo stato di blinking
        let counter = 0;
        const interval = setInterval(() => {
            this.visible = !this.visible; // Alterna la visibilità
            counter++;
            if (counter >= 6) 
            { // Dopo 6 cambi (3 secondi se ogni ciclo è 500ms), smette di lampeggiare
                clearInterval(interval);
                this.visible = true; // Assicura che il player sia visibile alla fine
                this.blinking = false; // Ripristina lo stato di blinking
            }
        }, 300);
        player.health = player.health - 15
    }
    
}
