class Player2
{
    constructor()
    {
        this.x = 100
        this.y = 500
        this.immagine = playerFermoSu
        this.xc = this.lato + this.x
        this.yc = this.lato + this.y
    }
    show()
    {
        image(this.immagine, this.x, this.y)
    }
    move()
    {   
        switch(movimento)
        {
            case 0:
                switch(temp)
                {
                    case 1:
                        this.immagine = playerFermoSu
                        break;
                    case 2:
                        this.immagine = playerFermoSinistra
                        break;
                    case 3:
                        this.immagine = playerFermoGiu
                        break;
                    case 4:
                        this.immagine = playerFermoDestra
                        break;
                }
                break;

            case 1:
                this.y -= 5
                this.yc -= 5
                this.immagine = playerMovimentoSu
                break;

            case 2:
                this.x -= 5
                this.xc -= 5
                this.immagine = playerMovimentoSinistra
                break;

            case 3:
                this.y += 5
                this.yc += 5
                this.immagine = playerMovimentoGiu
                break;

            case 4:
                this.x += 5
                this.xc += 5
                this.immagine = playerMovimentoDestra
                break;
        }
        
    }
    hitsVertical(blocco) 
    {
        if (this.x < blocco.x + 50 && this.x + this.immagine.width > blocco.x && this.y < blocco.y + 50 && this.y + this.immagine.width > blocco.y) 
        {
            if(movimento == 1) 
            {  
                this.y += 5
            }
            if(movimento == 3) 
            { 
                this.y -= 5
            }
        }
    }
    
    hitsOrizontal(blocco) 
    {
        if (this.x < blocco.x + 50 && this.x + this.immagine.width > blocco.x && this.y < blocco.y + 50 && this.y + this.immagine.width > blocco.y) 
        {
            if (movimento == 2) 
            { 
                this.x += 5
            }
            if (movimento == 4) 
            { 
                this.x -= 5
            }
        }
    }
    
}