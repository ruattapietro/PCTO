class Oggetto
{
    constructor()
    {
        this.x = larghezzaSfondo + 200
        this.y = randomBetween(0, altezzaSfondo - 150)
        this.xc
        this.yc
        this.oggetto = randomBetween(1, 13)

        switch(this.oggetto)
        {
            case 1:
            case 2:
            case 3:
            case 4:
                this.immagine = asteroide1
                break
            case 5:
            case 6:
            case 7:
            case 8:
            
                this.immagine = asteroide2
                break
            case 9:
            case 10:
            case 11:
            case 12:
                this.immagine = stella1
                this.punti = 1
                break
            case 13:
                this.immagine = stella2
                this.punti = 5
                break
        }
        
    }
    show()
    {
        image(this.immagine, this.x, this.y)
        this.xc = this.x + this.immagine.width / 2
        this.yc = this.y + this.immagine.height / 2
    }
    move()
    {
        this.x = this.x - 5
    }

}