class Blocco
{
    constructor(cx, cy)
    {
        this.x = cx
        this.y = cy
        this.immagine = pietra
    }
    show()
    {
        image(this.immagine, this.x, this.y)
    } 
}