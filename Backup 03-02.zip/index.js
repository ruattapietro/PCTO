let player
let player2
let sfondo
let altezzaSfondo = 830
let larghezzaSfondo = 1750
let punteggio = 0
let gioco = 0
let pietra
let asteroide1
let asteroide2
let stella1
let stella2
let blocchi = []
let oggetti = []
let pietraImmagine
let labirinto
let movimento = 0
let xInizioLabirinto = 315
let yInizioLabirinto = 50
let video
let poseNet
let pose
let skeleton
let xc
let yc
let navicella
let gameOver
let perso = false
let playerFermoSu
let playerFermoGiu
let playerFermoDestra
let playerFermoSinistra
let playerMovimentoSu
let playerMovimentoGiu
let playerMovimentoDestra
let playerMovimentoSinistra
let temp = 0


function preload()
{
    sfondo = loadImage('spazioAsteroidi.gif')
    sfondo2 = loadImage('spazioLabirinto.png')
    pietra = loadImage('pietra.png')
    labirinto = loadImage('Labirinto.png')
    asteroide1 = loadImage('asteroide1.gif')
    asteroide2 = loadImage('asteroide2.gif')
    stella1 = loadImage('stella1.png')
    stella2 = loadImage('stella2.png')
    navicella = loadImage('navicella.png')
    gameOver = loadImage('gameOver.png')
    playerFermoSu = loadImage('playerFermoSu.png')
    playerFermoGiu = loadImage('playerFermoGiu.png')
    playerFermoDestra = loadImage('playerFermoDestra.png')
    playerFermoSinistra = loadImage('playerFermoSinistra.png')
    playerMovimentoSu = loadImage('playerMovimentoSu.gif')
    playerMovimentoGiu = loadImage('playerMovimentoGiu.gif')
    playerMovimentoDestra = loadImage('playerMovimentoDestra.gif')
    playerMovimentoSinistra = loadImage('playerMovimentoSinistra.gif')

}
function setup()
{
    frameRate(60)
    player = new Player()
    player2 = new Player2()
    createCanvas(larghezzaSfondo, altezzaSfondo)
    video = createCapture(VIDEO);
    video.hide();
    poseNet = ml5.poseNet(video, modelLoaded);
    poseNet.on('pose', gotPoses);
}
function gotPoses(poses) 
{
    //console.log(poses); 
    if (poses.length > 0) 
    {
      pose = poses[0].pose;
      skeleton = poses[0].skeleton;
    }
}
  function modelLoaded() {
    console.log('poseNet ready');
  }
function draw()
{
    if (pose) 
    {
        let eyeR = pose.rightEye;
        let eyeL = pose.leftEye;
        let d = dist(eyeR.x, eyeR.y, eyeL.x, eyeL.y);
        fill(255, 0, 0);
        ellipse(pose.nose.x, pose.nose.y, 32);
        fill(0, 0, 255);
        ellipse(pose.rightWrist.x, pose.rightWrist.y, 32);
        ellipse(pose.leftWrist.x, pose.leftWrist.y, 32);
        
        for (let i = 0; i < pose.keypoints.length; i++) {
        let x = pose.keypoints[i].position.x;
        let y = pose.keypoints[i].position.y;
        fill(0,255,0);
        ellipse(x,y,16,16);
        }
        
        for (let i = 0; i < skeleton.length; i++) 
        {
            let a = skeleton[i][0];
            let b = skeleton[i][1];
            strokeWeight(2);
            stroke(255);
            line(a.position.x, a.position.y,b.position.x,b.position.y);  
            
            xc = mouseX
            yc = mouseY
        }
    }
    /*if(pose)
    {
        //let yPolso = pose.rightEye.y;
        //let xPolso = sfondo.width / 2 - pose.rightEye.x;
        //xc = map(xPolso, 330, 980, 0, sfondo.width)
        //yc = map(yPolso, 360, 560, 0, sfondo.height)
        
    }*/
    if(gioco == 0)
    {
        if(perso == false)
        {
            background(sfondo)
            if(random(1) < 0.03)
            {
                oggetti.push(new Oggetto())
            }
            for(let cont = oggetti.length - 1; cont >= 0; cont--)
            {
                let obj = oggetti[cont]
                obj.show()
                obj.move()

                if(player.hits(obj) && (obj.immagine == stella1 || obj.immagine == stella2))
                {
                    console.log("Stella colpita!")
                    punteggio += obj.punti
                    oggetti.splice(cont, 1)
                    console.log(punteggio)
                    document.getElementById("punteggio").textContent = punteggio;
                }
                if(player.hits(obj) && (obj.immagine == asteroide1 || obj.immagine == asteroide2))
                {
                    console.log("Asteroide colpito!")
                    player.blink() 
                    if(player.health <= 0)
                    {
                        perso = true
                    }               
                }
                
            }
            player.show()
            player.update()
        }
        if(perso)
        {
            background(gameOver)
        }
    }
    else if(gioco == 1)
    {
        background(sfondo2)
        creaLabirinto(xInizioLabirinto, yInizioLabirinto)
        disegnaLabirinto(xInizioLabirinto, yInizioLabirinto)
        player2.show()
        player2.move()
        hitBlocks()
    }
}
function randomBetween(min, max) 
{
    return Math.floor(Math.random() * (max - min + 1) + min)
}
function mouseClicked()
{
    if(gioco == 0)
        gioco = 1
    else if(gioco == 1)
        gioco = 0
}
function keyPressed()
{
    if(key.toLowerCase() == 'w')
    {
        movimento = 1
    }
    if(key.toLowerCase() == 'a')
    {
        movimento = 2
    }
    if(key.toLowerCase() == 's')
    {
        movimento = 3
    }
    if(key.toLowerCase() == 'd')
    {
        movimento = 4
    }
}
function keyReleased()
{
    if(key.toLowerCase() == 'w' || key.toLowerCase() == 'a' || key.toLowerCase() == 's' || key.toLowerCase() == 'd')
    {
        temp = movimento
        movimento = 0
    }
}
function hitBlocks()
{
    for(let blc of blocchi)
    {
        player2.hitsVertical(blc)
        player2.hitsOrizontal(blc)
    }
}
function delay(ms) 
{
    return new Promise(resolve => setTimeout(resolve, ms));
}
function creaLabirinto(xi, yi)
{
    blocchi.push(new Blocco(xi, yi))
    blocchi.push(new Blocco(xi + 100, yi))
    blocchi.push(new Blocco(xi + 150, yi))
    blocchi.push(new Blocco(xi + 200, yi))
    blocchi.push(new Blocco(xi + 250, yi))
    blocchi.push(new Blocco(xi + 300, yi))
    blocchi.push(new Blocco(xi + 350, yi))
    blocchi.push(new Blocco(xi + 400, yi))
    blocchi.push(new Blocco(xi + 450, yi))
    blocchi.push(new Blocco(xi + 500, yi))
    blocchi.push(new Blocco(xi + 550, yi))
    blocchi.push(new Blocco(xi + 600, yi))
    blocchi.push(new Blocco(xi + 650, yi))
    blocchi.push(new Blocco(xi + 700, yi))
    blocchi.push(new Blocco(xi + 750, yi))
    blocchi.push(new Blocco(xi + 800, yi))
    blocchi.push(new Blocco(xi + 850, yi))
    blocchi.push(new Blocco(xi + 900, yi))
    blocchi.push(new Blocco(xi + 950, yi))
    blocchi.push(new Blocco(xi + 1000, yi))
    blocchi.push(new Blocco(xi + 1050, yi))
    blocchi.push(new Blocco(xi + 1100, yi))
    blocchi.push(new Blocco(xi + 1150, yi))

    blocchi.push(new Blocco(xi + 1150, yi + 50))
    blocchi.push(new Blocco(xi + 1150, yi + 100))
    blocchi.push(new Blocco(xi + 1150, yi + 150))
    blocchi.push(new Blocco(xi + 1150, yi + 200))
    blocchi.push(new Blocco(xi + 1150, yi + 250))
    blocchi.push(new Blocco(xi + 1150, yi + 300))
    blocchi.push(new Blocco(xi + 1150, yi + 350))
    blocchi.push(new Blocco(xi + 1150, yi + 400))
    blocchi.push(new Blocco(xi + 1150, yi + 450))
    blocchi.push(new Blocco(xi + 1150, yi + 500))
    blocchi.push(new Blocco(xi + 1150, yi + 550))
    blocchi.push(new Blocco(xi + 1150, yi + 600))
    blocchi.push(new Blocco(xi + 1150, yi + 650))
    blocchi.push(new Blocco(xi + 1150, yi + 700))

    blocchi.push(new Blocco(xi, yi + 50))
    blocchi.push(new Blocco(xi, yi + 100))
    blocchi.push(new Blocco(xi, yi + 150))
    blocchi.push(new Blocco(xi, yi + 200))
    blocchi.push(new Blocco(xi, yi + 250))
    blocchi.push(new Blocco(xi, yi + 300))
    blocchi.push(new Blocco(xi, yi + 350))
    blocchi.push(new Blocco(xi, yi + 400))
    blocchi.push(new Blocco(xi, yi + 450))
    blocchi.push(new Blocco(xi, yi + 500))
    blocchi.push(new Blocco(xi, yi + 550))
    blocchi.push(new Blocco(xi, yi + 600))
    blocchi.push(new Blocco(xi, yi + 650))
    blocchi.push(new Blocco(xi, yi + 700))

    blocchi.push(new Blocco(xi, yi + 700))
    blocchi.push(new Blocco(xi + 50, yi + 700))
    blocchi.push(new Blocco(xi + 100, yi + 700))
    blocchi.push(new Blocco(xi + 150, yi + 700))
    blocchi.push(new Blocco(xi + 200, yi + 700))
    blocchi.push(new Blocco(xi + 250, yi + 700))
    blocchi.push(new Blocco(xi + 300, yi + 700))
    blocchi.push(new Blocco(xi + 350, yi + 700))
    blocchi.push(new Blocco(xi + 400, yi + 700))
    blocchi.push(new Blocco(xi + 450, yi + 700))
    blocchi.push(new Blocco(xi + 500, yi + 700))
    blocchi.push(new Blocco(xi + 550, yi + 700))
    blocchi.push(new Blocco(xi + 600, yi + 700))
    blocchi.push(new Blocco(xi + 650, yi + 700))
    blocchi.push(new Blocco(xi + 700, yi + 700))
    blocchi.push(new Blocco(xi + 750, yi + 700))
    blocchi.push(new Blocco(xi + 800, yi + 700))
    blocchi.push(new Blocco(xi + 850, yi + 700))
    blocchi.push(new Blocco(xi + 900, yi + 700))
    blocchi.push(new Blocco(xi + 950, yi + 700))
    blocchi.push(new Blocco(xi + 1000, yi + 700))
    blocchi.push(new Blocco(xi + 1100, yi + 700))
    blocchi.push(new Blocco(xi + 1150, yi + 700))
    blocchi.push(new Blocco(xi + 1000, yi + 650))

    blocchi.push(new Blocco(xi + 50, yi + 100))
    blocchi.push(new Blocco(xi + 100, yi + 100))
    blocchi.push(new Blocco(xi + 150, yi + 100))
    blocchi.push(new Blocco(xi + 200, yi + 100))
    blocchi.push(new Blocco(xi + 250, yi + 100))
    blocchi.push(new Blocco(xi + 300, yi + 100))

    blocchi.push(new Blocco(xi + 400, yi + 50))
    blocchi.push(new Blocco(xi + 400, yi + 100))
    blocchi.push(new Blocco(xi + 400, yi + 150))
    blocchi.push(new Blocco(xi + 400, yi + 200))
    
    blocchi.push(new Blocco(xi + 300, yi + 200))
    blocchi.push(new Blocco(xi + 350, yi + 200))
    blocchi.push(new Blocco(xi + 450, yi + 200))
    blocchi.push(new Blocco(xi + 500, yi + 200))

    blocchi.push(new Blocco(xi + 200, yi + 150))
    blocchi.push(new Blocco(xi + 200, yi + 200))

    blocchi.push(new Blocco(xi + 100, yi + 200))
    blocchi.push(new Blocco(xi + 100, yi + 250))
    blocchi.push(new Blocco(xi + 100, yi + 300))
    blocchi.push(new Blocco(xi + 100, yi + 350))
    blocchi.push(new Blocco(xi + 100, yi + 400))
    blocchi.push(new Blocco(xi + 100, yi + 450))
    blocchi.push(new Blocco(xi + 100, yi + 500))
    blocchi.push(new Blocco(xi + 100, yi + 550))
    blocchi.push(new Blocco(xi + 100, yi + 600))

    blocchi.push(new Blocco(xi + 150, yi + 600))
    blocchi.push(new Blocco(xi + 200, yi + 600))
    blocchi.push(new Blocco(xi + 250, yi + 600))
    blocchi.push(new Blocco(xi + 300, yi + 600))
    blocchi.push(new Blocco(xi + 350, yi + 600))
    blocchi.push(new Blocco(xi + 400, yi + 600))
    blocchi.push(new Blocco(xi + 250, yi + 650))

    blocchi.push(new Blocco(xi + 500, yi + 600))
    blocchi.push(new Blocco(xi + 500, yi + 550))
    
    blocchi.push(new Blocco(xi + 600, yi + 650))
    blocchi.push(new Blocco(xi + 600, yi + 600))
    blocchi.push(new Blocco(xi + 650, yi + 600))
    blocchi.push(new Blocco(xi + 700, yi + 600))
    blocchi.push(new Blocco(xi + 750, yi + 600))
    blocchi.push(new Blocco(xi + 800, yi + 600))
    blocchi.push(new Blocco(xi + 850, yi + 600))

    blocchi.push(new Blocco(xi + 950, yi + 600))
    blocchi.push(new Blocco(xi + 1000, yi + 600))
    blocchi.push(new Blocco(xi + 1050, yi + 600))

    blocchi.push(new Blocco(xi + 1050, yi + 550))
    blocchi.push(new Blocco(xi + 1050, yi + 500))
    blocchi.push(new Blocco(xi + 1050, yi + 450))
    blocchi.push(new Blocco(xi + 1050, yi + 400))

    blocchi.push(new Blocco(xi + 1000, yi + 400))
    blocchi.push(new Blocco(xi + 950, yi + 400))
    blocchi.push(new Blocco(xi + 900, yi + 400))
    blocchi.push(new Blocco(xi + 850, yi + 400))
    blocchi.push(new Blocco(xi + 850, yi + 450))
    blocchi.push(new Blocco(xi + 850, yi + 500))
    blocchi.push(new Blocco(xi + 900, yi + 500))
    blocchi.push(new Blocco(xi + 950, yi + 500))

    blocchi.push(new Blocco(xi + 150, yi + 300))
    blocchi.push(new Blocco(xi + 200, yi + 300))
    blocchi.push(new Blocco(xi + 250, yi + 300))
    blocchi.push(new Blocco(xi + 300, yi + 300))
    blocchi.push(new Blocco(xi + 350, yi + 300))
    blocchi.push(new Blocco(xi + 400, yi + 300))
    blocchi.push(new Blocco(xi + 450, yi + 300))
    blocchi.push(new Blocco(xi + 500, yi + 300))
    blocchi.push(new Blocco(xi + 550, yi + 300))
    blocchi.push(new Blocco(xi + 600, yi + 300))

    blocchi.push(new Blocco(xi + 600, yi + 250))
    blocchi.push(new Blocco(xi + 600, yi + 200))
    blocchi.push(new Blocco(xi + 650, yi + 200))

    blocchi.push(new Blocco(xi + 500, yi + 100))
    blocchi.push(new Blocco(xi + 550, yi + 100))
    blocchi.push(new Blocco(xi + 600, yi + 100))
    blocchi.push(new Blocco(xi + 650, yi + 100))
    blocchi.push(new Blocco(xi + 700, yi + 100))
    blocchi.push(new Blocco(xi + 750, yi + 100))
    blocchi.push(new Blocco(xi + 800, yi + 100))
    blocchi.push(new Blocco(xi + 850, yi + 100))
    blocchi.push(new Blocco(xi + 950, yi + 100))
    blocchi.push(new Blocco(xi + 950, yi + 50))

    blocchi.push(new Blocco(xi + 850, yi + 150))
    blocchi.push(new Blocco(xi + 850, yi + 200))
    blocchi.push(new Blocco(xi + 850, yi + 250))
    blocchi.push(new Blocco(xi + 850, yi + 300))
    blocchi.push(new Blocco(xi + 900, yi + 300))
    blocchi.push(new Blocco(xi + 950, yi + 300))
    blocchi.push(new Blocco(xi + 950, yi + 250))
    blocchi.push(new Blocco(xi + 950, yi + 200))
    blocchi.push(new Blocco(xi + 950, yi + 150))

    blocchi.push(new Blocco(xi + 1100, yi + 100))
    blocchi.push(new Blocco(xi + 1050, yi + 100))
    blocchi.push(new Blocco(xi + 1050, yi + 150))
    blocchi.push(new Blocco(xi + 1050, yi + 200))
    blocchi.push(new Blocco(xi + 1050, yi + 250))
    blocchi.push(new Blocco(xi + 1050, yi + 300))

    blocchi.push(new Blocco(xi + 750, yi + 150))
    blocchi.push(new Blocco(xi + 750, yi + 200))
    blocchi.push(new Blocco(xi + 750, yi + 250))
    blocchi.push(new Blocco(xi + 750, yi + 300))
    blocchi.push(new Blocco(xi + 750, yi + 350))
    blocchi.push(new Blocco(xi + 750, yi + 400))
    blocchi.push(new Blocco(xi + 750, yi + 450))
    blocchi.push(new Blocco(xi + 750, yi + 500))

    blocchi.push(new Blocco(xi + 700, yi + 500))
    blocchi.push(new Blocco(xi + 650, yi + 500))
    blocchi.push(new Blocco(xi + 600, yi + 500))
    blocchi.push(new Blocco(xi + 550, yi + 500))
    blocchi.push(new Blocco(xi + 500, yi + 500))
    blocchi.push(new Blocco(xi + 450, yi + 500))
    blocchi.push(new Blocco(xi + 400, yi + 500))
    blocchi.push(new Blocco(xi + 350, yi + 500))
    blocchi.push(new Blocco(xi + 300, yi + 500))
    blocchi.push(new Blocco(xi + 250, yi + 500))
    blocchi.push(new Blocco(xi + 200, yi + 500))

    blocchi.push(new Blocco(xi + 200, yi + 450))
    blocchi.push(new Blocco(xi + 200, yi + 400))
    blocchi.push(new Blocco(xi + 250, yi + 400))
    blocchi.push(new Blocco(xi + 300, yi + 400))
    blocchi.push(new Blocco(xi + 350, yi + 400))
    blocchi.push(new Blocco(xi + 400, yi + 400))
    blocchi.push(new Blocco(xi + 450, yi + 400))

    blocchi.push(new Blocco(xi + 600, yi + 450))
    blocchi.push(new Blocco(xi + 600, yi + 400))
    blocchi.push(new Blocco(xi + 550, yi + 400))
    blocchi.push(new Blocco(xi + 650, yi + 400))
}
function disegnaLabirinto(xi, yi)
{
    image(labirinto, xi, yi)
}

